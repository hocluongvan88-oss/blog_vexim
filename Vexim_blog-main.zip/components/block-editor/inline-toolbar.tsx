"use client"

import React, { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Bold, Italic, Underline, Link, Code, Unlink } from "lucide-react"
import { Input } from "@/components/ui/input"

interface InlineToolbarProps {
  onFormat: (command: string, value?: string) => void
}

export function InlineToolbar({ onFormat }: InlineToolbarProps) {
  const [position, setPosition] = useState<{ top: number; left: number } | null>(null)
  const [showLinkInput, setShowLinkInput] = useState(false)
  const [linkUrl, setLinkUrl] = useState("")
  const [hasExistingLink, setHasExistingLink] = useState(false)
  const toolbarRef = useRef<HTMLDivElement>(null)
  const savedRangeRef = useRef<Range | null>(null)

  useEffect(() => {
    const handleSelectionChange = () => {
      const selection = window.getSelection()
      
      if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
        setPosition(null)
        setShowLinkInput(false)
        return
      }

      const range = selection.getRangeAt(0)
      const rect = range.getBoundingClientRect()

      // Get the element containing the selection
      let anchorElement: HTMLElement | null = null
      if (selection.anchorNode) {
        if (selection.anchorNode.nodeType === Node.TEXT_NODE) {
          anchorElement = selection.anchorNode.parentElement
        } else {
          anchorElement = selection.anchorNode as HTMLElement
        }
      }

      if (!anchorElement) {
        setPosition(null)
        return
      }

      // Check if selection is within a contenteditable element or within the block editor
      const contentEditableParent = anchorElement.closest('[contenteditable="true"]')
      const blockEditorParent = anchorElement.closest('.block-editor-container')
      
      const isInContentEditable = contentEditableParent !== null || blockEditorParent !== null

      if (!isInContentEditable) {
        setPosition(null)
        return
      }

      // Only show if rect has valid dimensions
      if (rect.width === 0 || rect.height === 0) {
        setPosition(null)
        return
      }

      // Position toolbar above the selection
      setPosition({
        top: rect.top + window.scrollY - 45,
        left: rect.left + window.scrollX + rect.width / 2,
      })
    }

    document.addEventListener("selectionchange", handleSelectionChange)
    // Also listen to mouseup to catch selection after mouse drag
    document.addEventListener("mouseup", handleSelectionChange)
    // And keyup for keyboard selection (shift+arrows)
    document.addEventListener("keyup", handleSelectionChange)
    
    return () => {
      document.removeEventListener("selectionchange", handleSelectionChange)
      document.removeEventListener("mouseup", handleSelectionChange)
      document.removeEventListener("keyup", handleSelectionChange)
    }
  }, [])

  const handleFormat = (command: string) => {
    onFormat(command)
    // Keep selection after formatting
    setTimeout(() => {
      const selection = window.getSelection()
      if (selection && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0)
        const rect = range.getBoundingClientRect()
        setPosition({
          top: rect.top + window.scrollY - 45,
          left: rect.left + window.scrollX + rect.width / 2,
        })
      }
    }, 10)
  }

  const handleLinkClick = () => {
    const selection = window.getSelection()
    if (selection && selection.rangeCount > 0) {
      // Save the current selection/range so we can restore it later
      const range = selection.getRangeAt(0)
      savedRangeRef.current = range.cloneRange()
      
      // Check if selection already has a link
      const commonAncestor = range.commonAncestorContainer
      let linkElement: HTMLAnchorElement | null = null

      if (commonAncestor.nodeType === Node.ELEMENT_NODE) {
        linkElement = (commonAncestor as HTMLElement).closest("a")
      } else if (commonAncestor.parentElement) {
        linkElement = commonAncestor.parentElement.closest("a")
      }

      if (linkElement) {
        setLinkUrl(linkElement.href)
        setHasExistingLink(true)
      } else {
        setLinkUrl("")
        setHasExistingLink(false)
      }
    }
    setShowLinkInput(true)
  }

  const handleLinkSubmit = () => {
    if (linkUrl && savedRangeRef.current) {
      // Restore the saved selection
      const selection = window.getSelection()
      if (selection) {
        selection.removeAllRanges()
        selection.addRange(savedRangeRef.current)
        
        // Now apply the link
        document.execCommand("createLink", false, linkUrl)
        
        // Clear the saved range
        savedRangeRef.current = null
      }
    }
    setShowLinkInput(false)
    setLinkUrl("")
    setHasExistingLink(false)
  }

  const handleRemoveLink = () => {
    if (savedRangeRef.current) {
      const selection = window.getSelection()
      if (selection) {
        selection.removeAllRanges()
        selection.addRange(savedRangeRef.current)
        document.execCommand("unlink", false)
        savedRangeRef.current = null
      }
    }
    setShowLinkInput(false)
    setLinkUrl("")
    setHasExistingLink(false)
  }

  if (!position) return null

  return (
    <div
      ref={toolbarRef}
      className="fixed z-50 bg-popover border rounded-md shadow-lg p-1 flex items-center gap-1 animate-in fade-in-0 zoom-in-95"
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
        transform: "translateX(-50%)",
      }}
      onMouseDown={(e) => e.preventDefault()}
    >
      {!showLinkInput ? (
        <>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 bg-transparent"
            onClick={() => handleFormat("bold")}
            title="Bold (Ctrl+B)"
          >
            <Bold className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 bg-transparent"
            onClick={() => handleFormat("italic")}
            title="Italic (Ctrl+I)"
          >
            <Italic className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 bg-transparent"
            onClick={() => handleFormat("underline")}
            title="Underline (Ctrl+U)"
          >
            <Underline className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 bg-transparent"
            onClick={() => handleFormat("code")}
            title="Code"
          >
            <Code className="w-4 h-4" />
          </Button>
          <div className="w-px h-6 bg-border mx-1" />
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 bg-transparent"
            onClick={handleLinkClick}
            title="Add Link"
          >
            <Link className="w-4 h-4" />
          </Button>
        </>
      ) : (
        <div className="flex items-center gap-2 px-2">
          <Input
            type="url"
            placeholder="https://..."
            value={linkUrl}
            onChange={(e) => setLinkUrl(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault()
                handleLinkSubmit()
              } else if (e.key === "Escape") {
                setShowLinkInput(false)
                setLinkUrl("")
                setHasExistingLink(false)
              }
            }}
            className="h-7 text-sm w-48"
            autoFocus
          />
          <Button size="sm" className="h-7" onClick={handleLinkSubmit}>
            OK
          </Button>
          {hasExistingLink && (
            <Button 
              size="sm" 
              variant="destructive" 
              className="h-7" 
              onClick={handleRemoveLink}
              title="Xóa link"
            >
              <Unlink className="w-3 h-3" />
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
